import React from 'react';

const Bienvenida = props => {
  return (
    <h1>¡Hola, {props.nombre}!</h1>
  )
}

export default Bienvenida;